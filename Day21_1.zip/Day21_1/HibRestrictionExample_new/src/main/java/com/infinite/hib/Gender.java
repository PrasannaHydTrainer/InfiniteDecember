package com.infinite.hib;

public enum Gender {

	MALE, FEMALE
}
