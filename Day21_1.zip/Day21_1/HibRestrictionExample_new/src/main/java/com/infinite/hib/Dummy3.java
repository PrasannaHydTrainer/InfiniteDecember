package com.infinite.hib;

public class Dummy3 {

	public static void main(String[] args) {
		
	}
}
