package com.java.abs;

public abstract class Training {
	abstract String getTrainingDetails();
}
