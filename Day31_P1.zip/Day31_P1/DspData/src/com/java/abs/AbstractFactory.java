package com.java.abs;

public abstract class AbstractFactory {

	public abstract Training getDetails(String topic);
}
