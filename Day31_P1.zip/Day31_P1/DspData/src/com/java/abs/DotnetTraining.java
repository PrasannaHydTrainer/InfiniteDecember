package com.java.abs;

public class DotnetTraining extends Training {

	@Override
	String getTrainingDetails() {
		// TODO Auto-generated method stub
		return "Focus on .NET core only 5.0 framework and API is Mandetory...";
	}

	
}
