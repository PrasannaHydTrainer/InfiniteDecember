package com.java.abs;

public class ReactTraining extends Training {

	@Override
	String getTrainingDetails() {
		return "React training components/Routinga and Axios Mandetory...";
	}

}
