package com.java.abs;

public class JavaTraining extends Training {

	@Override
	String getTrainingDetails() {
		return "CoreJava/Jsp...More focus on EJB/HIbernate/JSF...Project Mandeotry...";
	}

}
