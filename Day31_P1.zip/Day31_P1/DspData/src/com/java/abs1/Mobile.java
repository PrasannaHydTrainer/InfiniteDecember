package com.java.abs1;

public interface Mobile {

	void name();
	void model();
	void price();
}
