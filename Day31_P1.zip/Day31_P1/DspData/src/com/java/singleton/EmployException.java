package com.java.singleton;

public class EmployException extends Exception {

	EmployException(String error) {
		super(error);
	}
}
