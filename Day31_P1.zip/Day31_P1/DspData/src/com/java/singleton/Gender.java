package com.java.singleton;

public enum Gender {

	MALE, FEMALE
}
