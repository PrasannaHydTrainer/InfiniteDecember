package com.infinite.hib;

import java.sql.SQLException;
import java.util.List;

public interface EmployDAO {

	List<Employ> showEmployDao();
}
