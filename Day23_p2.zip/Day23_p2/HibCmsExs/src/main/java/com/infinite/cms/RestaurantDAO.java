package com.infinite.cms;

public interface RestaurantDAO {

	String addRestaurantDao(Restaurant restaurant, Menu menu);
}
