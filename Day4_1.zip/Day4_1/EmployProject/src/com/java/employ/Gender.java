package com.java.employ;

public enum Gender {

	MALE, FEMALE
}
