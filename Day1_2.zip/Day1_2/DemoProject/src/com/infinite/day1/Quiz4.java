package com.infinite.day1;

public class Quiz4 {

	public static void main(String[] args) {
		int x=12;
		byte b=(byte) x;
		System.out.println(b);    
	}
}
