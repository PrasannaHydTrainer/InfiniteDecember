package com.infinite.day1;

public class Quiz3 {

	public static void main(String[] args) {
			char ch='A';
	      int x=ch;
	      System.out.println(x);
	}
}
