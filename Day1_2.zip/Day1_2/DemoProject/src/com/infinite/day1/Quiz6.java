package com.infinite.day1;

public class Quiz6 {

	public static void main(String[] args) {
		byte b=127;
		b+=15;
		System.out.println(b);
	}
}
