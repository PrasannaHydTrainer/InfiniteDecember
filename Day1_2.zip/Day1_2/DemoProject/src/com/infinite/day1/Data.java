package com.infinite.day1;

public class Data {

	public static void main(String[] args) {
		Demo obj= new Demo();
		obj.sayHello();
		obj.company();
	}
}
