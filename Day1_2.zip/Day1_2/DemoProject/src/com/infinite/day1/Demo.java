package com.infinite.day1;

public class Demo {
	
	public void sayHello() {
		System.out.println("Welcome to Java Programming...");
	}
	
	void company() {
		System.out.println("From infinite solutions...");
	}
	
	private void location() {
		System.out.println("From Visakhapatnam...");
	}
}
