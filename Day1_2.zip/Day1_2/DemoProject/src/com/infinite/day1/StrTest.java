package com.infinite.day1;

public class StrTest {

	public static void main(String[] args) {
		String s1="Lata", s2="Makrand",s3="Aditya",s4="Lata";
		System.out.println(s1.hashCode());
		System.out.println(s2.hashCode());
		System.out.println(s3.hashCode());
		System.out.println(s4.hashCode());
	}
}
