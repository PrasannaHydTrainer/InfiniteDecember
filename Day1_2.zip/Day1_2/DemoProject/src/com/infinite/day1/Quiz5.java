package com.infinite.day1;

public class Quiz5 {

	public static void main(String[] args) {
		byte x=12;
		int b=x;
		System.out.println(b);
	}
}
