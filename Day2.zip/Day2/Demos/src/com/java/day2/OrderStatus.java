package com.java.day2;

public enum OrderStatus {

	PENDING, ACCEPTED, REJECTED
}
