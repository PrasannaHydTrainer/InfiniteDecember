package com.java.day2;

public class EmployShow {

	public static void main(String[] args) {
		Employ employ1 = new Employ();
		employ1.empno=1;
		employ1.name="Aditya";
		employ1.basic=83823;
		System.out.println(employ1);
	}
}
