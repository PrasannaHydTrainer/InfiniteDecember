package com.java.day2;

public class EnumEx2 {

	public static void main(String[] args) {
		OrderStatus ordStatus = OrderStatus.PENDING;
		System.out.println(ordStatus);
	}
}
