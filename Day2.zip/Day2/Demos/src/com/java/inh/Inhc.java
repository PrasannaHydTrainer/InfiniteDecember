package com.java.inh;

public class Inhc {

	public static void main(String[] args) {
		C2 obj = new C2();
	}
}
