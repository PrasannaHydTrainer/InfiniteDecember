package com.java.collections;

public class Ex1 {
	public static void main(String[] args) {
		
	
	
	//int i = 100;
	//float f= 12.5f;
	//String s = "hello";
	
	//String fs=String.format("integer value is %d" +"float %f" +" string %s",i,f,s);
	//System.out.println(fs);
		
		String str1 = String.format("%d", 101);
		String str2 = String.format("%s", "amar sing");
		String str3 = String.format("%f", 101.00);
		String str4 = String.format("%x", 101);
		String str5 = String.format("%c", 'c');
		System.out.println(str1);
		System.out.println(str2);
		System.out.println(str3);
		System.out.println(str4);
		System.out.println(str5);
	}

}
