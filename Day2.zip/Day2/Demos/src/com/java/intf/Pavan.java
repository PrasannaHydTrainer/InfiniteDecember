package com.java.intf;

public class Pavan implements ITraining {

	@Override
	public void name() {
		System.out.println("Name is Pavan...");
	}

	@Override
	public void email() {
		System.out.println("Email is Pavan@gmail.com");
	}

}
