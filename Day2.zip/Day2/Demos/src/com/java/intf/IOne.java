package com.java.intf;

public interface IOne {
	void name();
}
