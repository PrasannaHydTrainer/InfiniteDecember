package com.java.intf;

public class Sarathi implements ITraining {

	@Override
	public void name() {
		System.out.println("Name is Partha Sarathi...");
	}

	@Override
	public void email() {
		System.out.println("Email is sarathi@gmail.com");
	}

}
