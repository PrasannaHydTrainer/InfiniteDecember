package com.java.abs;

public class DeveloperEmploy extends Employee {

	public DeveloperEmploy(int empno, String name, double basic) {
		super(empno, name, basic);
		// TODO Auto-generated constructor stub
	}

	@Override
	public Employee showEmploy(Employee employee) {
		// TODO Auto-generated method stub
		return employee;
	}

	

}
