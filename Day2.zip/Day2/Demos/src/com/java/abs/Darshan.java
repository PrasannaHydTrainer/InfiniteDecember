package com.java.abs;

public class Darshan extends Training {

	@Override
	public void name() {
		System.out.println("Name is Darshan...");
	}

	@Override
	public void email() {
		System.out.println("Email is darshan@gmail.com");
	}

}
