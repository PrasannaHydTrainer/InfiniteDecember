package com.java.abs;

public class Chetan extends Training {

	@Override
	public void name() {
		System.out.println("Name is Chethan...");
	}

	@Override
	public void email() {
		System.out.println("Name is Chethan@gmail.com");
	}

}
