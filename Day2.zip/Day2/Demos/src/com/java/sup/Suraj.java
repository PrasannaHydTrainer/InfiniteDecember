package com.java.sup;

public class Suraj extends Employ {

	public Suraj(int empno, String name, double basic) {
		super(empno, name, basic);
		// TODO Auto-generated constructor stub
	}

}
