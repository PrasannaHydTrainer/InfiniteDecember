package com.java.sup;

public class SupEx {

	public static void main(String[] args) {
		Second obj = new Second();
		obj.show();
	}
}
