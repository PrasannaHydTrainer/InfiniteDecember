package com.java.sup;

public class Akhila extends Employ {

	public Akhila(int empno, String name, double basic) {
		super(empno, name, basic);
		// TODO Auto-generated constructor stub
	}

}
