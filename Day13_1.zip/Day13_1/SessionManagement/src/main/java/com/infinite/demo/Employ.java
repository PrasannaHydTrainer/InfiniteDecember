package com.infinite.demo;

public class Employ {

}
