package com.infinite.cms;

import java.util.List;

public interface WalletDAO {

	List<Wallet> showCustomerWalletDao(int custId);
}
