package com.infinite.cms;

public enum WalletSource {
	PAYTM, CREDIT_CARD, DEBIT_CARD
}
