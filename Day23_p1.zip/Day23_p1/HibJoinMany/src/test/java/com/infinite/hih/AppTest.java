package com.infinite.hih;

import org.junit.Test;

import com.infinite.hib.App;

public class AppTest {

  @Test
  public void testMain() {
    App.main(null);
  }

}
