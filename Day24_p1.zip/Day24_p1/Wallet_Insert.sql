
Insert into wallet(Cus_ID,Wal_Source,Wal_Amount)
values(4,'PAYTM',85533),
(4,'CREDIT_CARD',48222),
(4,'DEBIT_CARD',48224),
(5,'PAYTM',90333),
(5,'CREDIT_CARD',75332),
(5,'DEBIT_CARD',83322);
