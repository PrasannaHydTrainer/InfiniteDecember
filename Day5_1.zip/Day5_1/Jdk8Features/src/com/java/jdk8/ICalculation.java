package com.java.jdk8;

@FunctionalInterface 
public interface ICalculation {
	int calc(int a, int b);
}
