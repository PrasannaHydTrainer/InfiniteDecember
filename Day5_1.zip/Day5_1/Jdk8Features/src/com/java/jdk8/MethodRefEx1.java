package com.java.jdk8;

public class MethodRefEx1 {

}
