package com.java.jdk8;

public interface IGreeting {
	void salution();
}
