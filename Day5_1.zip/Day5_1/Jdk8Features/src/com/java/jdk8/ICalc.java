package com.java.jdk8;

@FunctionalInterface
public interface ICalc {
    int calc(int a, int b);
}
