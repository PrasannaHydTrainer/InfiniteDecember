-- Display the last occurrence of given char in a string 

-- ex : value as 'Bhagyashree' char 'a' exists 2 times
-- print the last occurrence 

-- Display all Ename of Emp table in sentence case means 
-- only first char upper case remaining in lower case 

-- Take fullName and split into firstName and LastName 

-- Ex 'Ashish Baratam' FirstName Ashish, LastName Baratam

-- IN World 'misissipi' count no.of i's 

-- Add 5 years 10 months and 6 days to the today's date 

-- Display the first day of the next month 

-- Display the last Da of the current Year

-- Display all friday's of current Month
